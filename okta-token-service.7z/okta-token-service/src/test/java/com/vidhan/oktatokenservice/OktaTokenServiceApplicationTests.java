package com.vidhan.oktatokenservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OktaTokenServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
