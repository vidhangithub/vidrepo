package com.vidhan.kafka.topictodb;

import java.util.*;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import com.vidhan.kafka.util.JDBCUtilType4;
import java.sql.*;
import java.sql.Date;


    public class TopicToDB
    {
    	
 
    private static final String topic = "producttopic";
 
    public Consumer<Integer, String> initializeConsumer() {
             Properties props = new Properties();         
             props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
             props.put(ConsumerConfig.GROUP_ID_CONFIG, "NBSTestConsumer");
             props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
             props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
             props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000");
             props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.IntegerDeserializer");
             props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
             
             Consumer<Integer, String> consumer = new KafkaConsumer<Integer, String>(props);
             // Subscribe to the topic.
             consumer.subscribe(Collections.singletonList(topic));
             return consumer;
       }

       public void consume() {
    	   List<String> productList= new ArrayList<String>();
    	   final Consumer<Integer, String> consumer = initializeConsumer();
    	   Connection con = null;
    	   PreparedStatement ps  = null;
    	   
			try {
				  con = JDBCUtilType4.getDestinationOracleconnection();
	        	  ps = con.prepareStatement("insert into product_replica values (?, ?, ?, ?)");
	        	  while (true) {
		        	
		        	  ConsumerRecords<Integer, String> records = consumer.poll(1000);
		              for (ConsumerRecord<Integer, String> record : records) {
		              	String content=new String(record.value());
		              	String contentSenitizerOne = content.replaceAll("\\[", "");
		              	String contentSenitizerTwo = contentSenitizerOne.replaceAll("\\]", "");
		            	String contentSenitizerThree = contentSenitizerTwo.replaceAll("\\n", "");
		              	System.out.println(contentSenitizerThree);
		              	String[] contentArrayCoversion = contentSenitizerThree.split(" ");
		              	productList = Arrays.asList(contentArrayCoversion);
		              	System.out.println(productList.size());
		              	for(String product: productList){
		              		String col1=new String(product.split(",")[0]);
							String col2=new String(product.split(",")[1]);
							String col3=new String(product.split(",")[2]);
							Date dateColumn = Date.valueOf(col3);
							String col4=new String(product.split(",")[3]);
							//System.out.println(col1+" | "+col2+" | "+col3+" | "+col4);
							ps.setString(1, col1);
							ps.setString(2, col2);
							ps.setDate(3, dateColumn);
							ps.setString(4, col4);
							int x = ps.executeUpdate();
							if (x ==1) {
								System.out.println("----------------------------------");
								System.out.println("Following Record Updated in DB :-");
								System.out.println(product);
							} else System.out.println("Record insertion failed:::");
							
		             	}
					
		              }
		              consumer.commitAsync();
		        }
		      
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
					consumer.unsubscribe();
				    consumer.close();
				    JDBCUtilType4.cleanUP(con, ps);
			        
			}
       }

       public static void main(String[] args) throws InterruptedException {
             TopicToDB kafkaConsumer = new TopicToDB();
             kafkaConsumer.consume();
       }
   }
