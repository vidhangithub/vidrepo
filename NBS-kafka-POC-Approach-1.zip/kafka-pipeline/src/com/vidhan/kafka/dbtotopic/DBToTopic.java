package com.vidhan.kafka.dbtotopic;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.vidhan.kafka.util.JDBCUtilType4;

public class DBToTopic {
	
	private static Producer<Integer, String> producer;
	private static final String topic = "producttopic";
	
	public Producer<Integer, String> initializeProducer() {
		Properties producerPorps = new Properties();
		producerPorps.put("metadata.broker.lsit","localhost:9092");
		producerPorps.put("bootstrap.servers", "localhost:9092");
		producerPorps.put("client.id", "NBSTestProducer");
		producerPorps.put("key.serializer", "org.apache.kafka.common.serialization.IntegerSerializer");
		producerPorps.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		producerPorps.put("request.required.acks", "1");	
		producer = new KafkaProducer<Integer, String>(producerPorps);
		return producer;
		
	}
	
	public String getMsgFromDB( ) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		String msg = null;
		List<String> productList= new ArrayList<String>();
		try {
			con = JDBCUtilType4.getSourceOracleconnection();
			st = con.createStatement();
			//String sql="select * from product";
			String sql="select * from product where productcategory = 'BB'";
			//String sql="select * from product where productcategory = 'TV'";
			//String sql="select * from product where productcategory = 'PH'";
			//String sql="select * from product where productcategory = 'SIM'";
			//String sql="select * from product where productcategory = 'BB' OR productcategory = 'SIM'";
			rs=st.executeQuery(sql);
			while(rs.next()){
				String productID = rs.getString(1);
				String shortDesc = rs.getString(2);
				Date prdctActvtnDate = rs.getDate(3);
				String prdctCatgry =rs.getString(4);
				msg = productID+","+shortDesc+","+prdctActvtnDate+","+prdctCatgry+"\n";
				productList.add(msg);
			  }
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtilType4.cleanUP(con, st, rs);
		}

		
		return productList.toString();
	}
	
	public static void main(String[] args) {
		DBToTopic dbToTopic = new DBToTopic();
		String msg = dbToTopic.getMsgFromDB();
		int msgNumber = 1;
		try {
			dbToTopic.initializeProducer().send(new ProducerRecord<Integer, String>(topic, msgNumber, msg)).get();
			System.out.println("Message Sent Successfully ::::");
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		
		
	}

}
