package com.vidhan.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan("com.vidhan")
@EntityScan("com.vidhan.models")
@EnableJpaRepositories("com.vidhan.repositories")
public class VidEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(VidEmployeeApplication.class, args);
	}

}
