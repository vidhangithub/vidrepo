package com.damech.ui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.damech.ui")
public class DamechUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DamechUiApplication.class, args);
	}

}
